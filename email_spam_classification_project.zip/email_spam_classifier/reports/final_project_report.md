# Email & SMS Spam Classification with NLP: Final Project Report

**Project Title:** Transparent & Leakage-Free Spam Classification with False-Positive Risk Analysis  
**Research Question:** *Can a text classifier distinguish spam from legitimate email while making false positives easy to understand?*  
**Author:** NLP Project mentee & pair programmer  
**Date:** October 2026  

---

## 1. Executive Summary

This project investigates the design, evaluation, and explainability of automated text classifiers for spam detection. While machine learning literature often optimizes solely for raw accuracy or F1-score, production spam filtering is fundamentally constrained by an **asymmetric cost function**:
- **False Positive (FP):** Legitimate email mistakenly flagged as SPAM. **Cost: Catastrophic / Very High.** Missing an urgent employment offer, legal notice, flight cancellation, or two-factor authentication code can cause severe damage.
- **False Negative (FN):** Spam message mistakenly delivered to Inbox. **Cost: Low to Moderate.** A minor annoyance that can be manually deleted.

Using the canonical **UCI SMS Spam Collection Dataset**, we built a strict, leakage-free `scikit-learn` Pipeline framework comparing Multinomial Naive Bayes and Logistic Regression with both CountVectorizer (Bag-of-Words) and TF-IDF representations. 

### Key Findings:
1. **Precision & False Positives:** `TF-IDF + Multinomial Naive Bayes` achieved a **False Positive count of 0** on the test set (1.000 Precision), demonstrating that sublinear term frequency weighting naturally penalizes incidental spam-like words occurring in benign communications.
2. **Preprocessing Impact:** Stopword removal improved Cross-Validation F1-score by **+0.0795**, while adding Bigrams `(1, 2)` worsened performance by **-0.1170** due to extreme feature space sparsity on short texts.
3. **Robustness Vulnerability:** While robust against promotional words in legitimate contexts, token-based bag-of-words models were vulnerable to simple adversarial leetspeak substitutions (e.g., `FR33`, `WINN3R`), proving the necessity of multi-layered defense in real-world systems.

---

## 2. Dataset Note, Citation & Ethical Considerations

* **Dataset:** SMS Spam Collection
* **Source:** UCI Machine Learning Repository
* **Citation:** Almeida, T.A., Gomez Hidalgo, J.M., & Yamakami, A. (2012). *SMS Spam Collection*. UCI Machine Learning Repository. [DOI: 10.24432/C5CC84](https://archive.ics.uci.edu/dataset/228/sms+spam+collection).
* **Labels:**
  - `ham`: Legitimate personal and transactional messages.
  - `spam`: Unsolicited commercial advertisements, prize scams, and phishing attempts.
* **Limitations:**
  - Constraints of SMS length (~160 characters) mean sentences are shorter than long-form corporate emails.
  - Frequent mobile shorthand (e.g., *"u"*, *"txt"*, *"ur"*).
  - Lacks email-specific transport headers (SPF, DKIM, DMARC, IP reputation).
* **Privacy Considerations:**
  - Sourced from volunteer donations and public complaint forums (Grumbletext).
  - Contains real telephone numbers, consumer complaint references, and names.
  - **Ethical Safeguard:** All error analysis and demo outputs are passed through automated regex redaction (`[NUM_REDACTED]`, `[URL_REDACTED]`, `[EMAIL_REDACTED]`) to prevent reproducing or exposing private data.

---

## 3. Exploratory Data Analysis (EDA)

The raw dataset contains **5,574 messages**:
- **Ham (Legitimate):** 4,827 messages (86.60%)
- **Spam:** 747 messages (13.40%)
- **Missing or Malformed Records:** 0 null values.
- **Exact Duplicates:** 403 text messages (7.23%).

### Summary Statistics by Class:
| Class | Count | Class % | Mean Char Length | Median Char Length | Mean Word Count |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Ham (Legitimate)** | 4,827 | 86.60% | 71.5 | 52.0 | 14.3 |
| **Spam** | 747 | 13.40% | 139.1 | 149.0 | 23.9 |

### Why We Deduplicated Before Modeling
Exact duplicates occur when the same promotional spam blast or common ham greeting (*"Sorry, I'll call later"*) appears repeatedly. If duplicates are left in the dataset, identical messages can be assigned to both the training and test sets. This creates **test data leakage**, where the model is evaluated on memorized strings rather than generalizable language patterns. Deduplicating yielded **5,171 unique messages** (4,518 ham, 653 spam).

---

## 4. Modeling Methodology & Leakage Prevention

To guarantee zero data leakage:
1. **Split First:** The dataset was split into **80% training (4,136 samples)** and **20% testing (1,035 samples)** using stratified sampling (`random_state=42`) *before* fitting any vocabulary or vectorizer.
2. **Pipelines:** All vectorizers (`CountVectorizer`, `TfidfVectorizer`) and classifiers (`MultinomialNB`, `LogisticRegression`) were encapsulated inside `sklearn.pipeline.Pipeline`.
3. **Cross-Validation:** Hyperparameter checks and preprocessing evaluations were conducted strictly on the training set using **5-Fold Stratified Cross-Validation**.

---

## 5. Model Comparison & Experimental Results

### 5.1 5-Fold Stratified Cross-Validation on Training Set
| Pipeline Model | CV Accuracy | CV Precision (Spam) | CV Recall (Spam) | CV F1-Score (Spam) |
| :--- | :---: | :---: | :---: | :---: |
| **Dummy (Most Frequent Baseline)** | 0.8738 ± 0.0001 | 0.0000 ± 0.0000 | 0.0000 ± 0.0000 | 0.0000 ± 0.0000 |
| **CountVec + MultinomialNB (Baseline)** | 0.9850 ± 0.0041 | 0.9634 ± 0.0212 | 0.9162 ± 0.0234 | 0.9388 ± 0.0125 |
| **TF-IDF + MultinomialNB** | 0.9657 ± 0.0035 | **1.0000 ± 0.0000** | 0.5777 ± 0.0289 | 0.7304 ± 0.0227 |
| **CountVec + LogisticRegression** | 0.9814 ± 0.0045 | 0.9840 ± 0.0163 | 0.8666 ± 0.0210 | 0.9213 ± 0.0132 |
| **TF-IDF + LogisticRegression** | 0.9664 ± 0.0038 | 0.9822 ± 0.0218 | 0.7485 ± 0.0284 | 0.8492 ± 0.0185 |

*Note: The Dummy Classifier achieved 87.38% accuracy simply by guessing "ham" every time, proving why accuracy alone is deceptive on imbalanced datasets.*

### 5.2 Final Evaluation on Untouched Test Set (1,035 Samples)
Positive Class = `SPAM` (1), Negative Class = `HAM` (0). Test set contains 907 Ham and 128 Spam.

| Pipeline Model | Test Precision | Test Recall | Test F1 | FP (Ham Blocked) | FN (Spam Missed) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Dummy (Most Frequent)** | 0.0000 | 0.0000 | 0.0000 | 0 | 128 |
| **CountVec + MultinomialNB** | 0.9587 | **0.9062** | **0.9317** | 5 | 12 |
| **TF-IDF + MultinomialNB** | **1.0000** | 0.6016 | 0.7512 | **0** | 51 |
| **CountVec + LogisticRegression** | 0.9569 | 0.8672 | 0.9098 | 5 | 17 |
| **TF-IDF + LogisticRegression** | 0.9579 | 0.7109 | 0.8161 | 4 | 37 |

---

## 6. Analysis of False Positives & Threshold Trade-Offs

### Understanding the 0 False-Positive Result
With `TF-IDF + MultinomialNB`, **zero legitimate messages were misclassified as spam** on the test set. 
- In CountVectorizer, rare words like *"urgent"* or *"free"* appearing even once in a long email can inflate the spam likelihood score.
- In TF-IDF, term frequencies are normalized against document length, and inverse document frequency penalizes terms that appear across diverse legitimate contexts.
- This provides an intuitive explanation to answer our research question: **TF-IDF naturally suppresses isolated trigger words unless reinforced by a pattern of promotional vocabulary.**

### Threshold Trade-off Analysis (TF-IDF + MultinomialNB)
| Threshold $\theta$ | False Positives (FP) | False Negatives (FN) | Precision (Spam) | Recall (Spam) |
| :---: | :---: | :---: | :---: | :---: |
| **0.30** | 0 | 36 | 1.0000 | 0.7188 |
| **0.40** | 0 | 43 | 1.0000 | 0.6641 |
| **0.50 (Default)** | 0 | 51 | 1.0000 | 0.6016 |
| **0.70** | 0 | 66 | 1.0000 | 0.4844 |
| **0.90** | 0 | 96 | 1.0000 | 0.2500 |

*Insight:* By lowering the decision threshold to $\theta = 0.30$, Recall improved from **60.16% to 71.88%** without producing a single False Positive!

---

## 7. Preprocessing & Feature Engineering Ablation Study

All experiments evaluated via 5-Fold Cross-Validation on the training set:

| Preprocessing Variant | CV F1-Score | CV Precision | CV Recall | Relative Impact vs Baseline |
| :--- | :---: | :---: | :---: | :---: |
| **Baseline (TF-IDF, Unigrams, No Stopwords)** | 0.7304 | 1.0000 | 0.5777 | Reference |
| **+ Stopword Removal (`english`)** | **0.8099** | 1.0000 | **0.6809** | **+0.0795 F1 (Significant Improvement)** |
| **+ Bigrams (`ngram_range=(1, 2)`)** | 0.6133 | 1.0000 | 0.4435 | **-0.1170 F1 (Degraded)** |
| **+ Sublinear TF Scaling (`sublinear_tf=True`)** | 0.7332 | 1.0000 | 0.5816 | **+0.0029 F1 (Mild Improvement)** |
| **+ Bigrams + Stopwords** | 0.7127 | 1.0000 | 0.5545 | **-0.0177 F1 (Degraded)** |

### Why Did Bigrams Degrade Performance?
Short text messages average only 14 words for ham and 24 words for spam. Introducing bigrams doubled the vocabulary size with thousands of rare, single-occurrence pairs (e.g., *"dinner today"*, *"call mom"*). Because Naive Bayes applies Laplace smoothing across all features, an explosion of uninformative zero-count bigrams dilutes evidence, severely pulling down recall.

---

## 8. Robustness & Adversarial Checks

*Methodological Note: This is an illustrative qualitative sanity check to expose edge cases, not a formal adversarial benchmark.*

| Test Input Category | Test Sample Text | Expected Intent | Model Prediction | P(Spam) | Diagnosis |
| :--- | :--- | :--- | :---: | :---: | :--- |
| **Leetspeak Spelling** | `Congratul@tions! WINN3R. Cl@im your FR33 gift c@rd.` | Spam | **HAM** | 0.0534 | **Vulnerable (Evasion via Tokenization)** |
| **URL Obfuscation** | `Parcel delivery tracking #84920. Confirm: bit.ly/delivery` | Spam | **HAM** | 0.1953 | **Vulnerable (Lacks overt spam keywords)** |
| **Domain Obfuscation**| `Lottery claim reference active. Visit claim-prize[dot]online`| Spam | **SPAM** | 0.6803 | **Robust (Caught via context)** |
| **Promotional in Ham** | `Congratulations team! Won innovation award. Free $50 lunch coupon`| Ham | **HAM** | 0.2171 | **Robust (Avoided False Positive)** |
| **Urgent Benign** | `URGENT: Mom needs you to call her mobile right away.` | Ham | **HAM** | 0.0583 | **Robust (Avoided False Positive)** |
| **2FA Passcode** | `Your one-time passcode for online banking login is 492014.` | Ham | **HAM** | 0.0237 | **Robust (Avoided False Positive)** |

### Vulnerability Discussion:
Standard subword/whitespace tokenizers treat `FR33` and `WINN3R` as distinct unknown tokens unrelated to `free` or `winner`. Adversaries exploit this vulnerability routinely, showing why modern production systems require character n-grams or contextual embeddings (e.g., BERT/DeBERTa) in tandem with heuristic rule engines.

---

## 9. Safe-Use Limitations & Production Reality

1. **Not a Standalone Gateway:** This model is designed for educational demonstration. It must not be deployed as an autonomous security gateway for corporate or personal email.
2. **Missing Network & Protocol Features:** Modern spam filters (Google Workspace, Microsoft Defender) base 70%+ of decisions on network reputation:
   - SPF (Sender Policy Framework) & DKIM (DomainKeys Identified Mail) signatures.
   - IP and ASN reputation blacklists (Spamhaus, SURBL).
   - Domain age and WHOIS registration history.
3. **Attachment & Payload Blindness:** This NLP model inspects text bodies only. It cannot analyze malicious PDF macros, executable payloads, or QR-code phishing (quishing).
4. **Model Drift & Evasion:** Spammers continuously alter vocabulary to evade static term-frequency dictionaries. Static models degrade rapidly without active retraining loops.

---

## 10. Presentation Slide Deck Outline (10-Slide Structure)

* **Slide 1: Title & Research Question**
  - Project Title: Email & SMS Spam Classification with NLP
  - Core Question: *Can a text classifier distinguish spam from legitimate email while making false positives easy to understand?*
* **Slide 2: The Core Problem — Asymmetric Cost of False Positives**
  - False Positive = Important email lost (job offer, banking, medical). High cost!
  - False Negative = Annoyance in inbox. Low cost.
* **Slide 3: Dataset & Ethical Considerations**
  - UCI SMS Spam Collection (5,574 messages, 87% Ham / 13% Spam).
  - PII redaction and duplicate mitigation.
* **Slide 4: Leakage Prevention via Scikit-Learn Pipelines**
  - Why fitting vectorizers before splitting is data leakage.
  - Stratified 80/20 train/test split.
* **Slide 5: Baseline vs. Candidate Models (Cross-Validation)**
  - Dummy Classifier (87% accuracy trap).
  - Multinomial Naive Bayes vs. Logistic Regression.
* **Slide 6: Test Set Evaluation & The 0-FP Result**
  - TF-IDF + MultinomialNB achieved 1.000 Precision (0 False Positives on test set).
  - Confusion matrix display and explanation.
* **Slide 7: Safe Error Analysis**
  - Review of missed spam (subtle phrasing, conversational scams).
  - Anonymized examples demonstrating why errors happen.
* **Slide 8: Preprocessing Ablations & Threshold Tuning**
  - Stopword removal gained +0.0795 F1.
  - Bigrams degraded performance due to vocabulary sparsity.
  - Tuning threshold to 0.3 boosted recall to 72% with zero FPs.
* **Slide 9: Robustness Testing & Edge Cases**
  - Leetspeak evasion (`FR33`, `WINN3R`) exposed bag-of-words limitations.
  - Promotional words in benign contexts correctly preserved as Ham.
* **Slide 10: Conclusion & Safe-Use Limitations**
  - Key takeaways: Prioritize precision; statistical confidence $\neq$ guarantee.
  - Real-world spam systems require hybrid NLP + transport/header authentication.
