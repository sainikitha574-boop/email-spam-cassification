"""
robustness.py - Qualitative robustness test suite for spam classifiers.

IMPORTANT METHODOLOGICAL NOTE:
This module demonstrates edge-case sensitivity and linguistic perturbations.
It is an illustrative, educational sanity check and DOES NOT constitute a
formal adversarial robustness evaluation, randomized perturbation benchmark,
or guarantee of production resilience against determined adversaries.
"""

from typing import List, Dict, Any
import pandas as pd


ROBUSTNESS_TEST_CASES = [
    # 1. Obfuscated Spelling & Leetspeak
    {
        "category": "Spelling Variation / Leetspeak",
        "description": "Spam intent disguised with numbers and special symbols replacing vowels",
        "text": "Congratul@tions! You have been selected as a WINN3R. Cl@im your FR33 gift c@rd now by texting back.",
        "expected_intent": "Spam (Obfuscated)",
    },
    {
        "category": "Spelling Variation / Leetspeak",
        "description": "Phishing text using character substitutions",
        "text": "URG3NT: Your b@nk acc0unt requires immedi@te verific@tion. C@ll [PHONE_REDACTED] to restore access.",
        "expected_intent": "Spam (Obfuscated)",
    },

    # 2. Obfuscated URLs & Link Shorteners
    {
        "category": "URL Obfuscation",
        "description": "Suspicious shortened link without explicit spam trigger words",
        "text": "Notice regarding parcel delivery tracking #84920. Click here to confirm address: bit.ly/delivery-update-2026",
        "expected_intent": "Spam (Phishing Link)",
    },
    {
        "category": "URL Obfuscation",
        "description": "Defanged link and unusual top-level domain",
        "text": "Your lottery claim reference is active. Visit claim-prize[dot]online to register your wallet.",
        "expected_intent": "Spam (Obfuscated Domain)",
    },

    # 3. Promotional Wording in Legitimate Context (High Risk of False Positive)
    {
        "category": "Promotional in Legitimate Context",
        "description": "Internal work email celebrating an award with discount perk",
        "text": "Congratulations team! We won the quarterly innovation award. You all get a free $50 coupon for lunch today.",
        "expected_intent": "Ham (Benign Workplace Email)",
    },
    {
        "category": "Promotional in Legitimate Context",
        "description": "Personal message talking about a promotional bargain",
        "text": "Hey Sarah, I saw that store has a buy 1 get 1 free offer today. Let me know if you want me to pick up anything.",
        "expected_intent": "Ham (Personal Conversation)",
    },

    # 4. Ordinary Legitimate Messages with Urgency / Transactional Words
    {
        "category": "Urgent Benign Message",
        "description": "Urgent family request containing urgency keywords",
        "text": "URGENT: Mom had an appointment and needs you to call her back immediately on her mobile.",
        "expected_intent": "Ham (Urgent Family)",
    },
    {
        "category": "Urgent Benign Message",
        "description": "Legitimate banking confirmation with security code",
        "text": "Your one-time passcode for online banking login is 492014. Do not share this code with anyone.",
        "expected_intent": "Ham (Transactional 2FA)",
    },

    # 5. Standard Conversational Ham
    {
        "category": "Standard Ham Baseline",
        "description": "Everyday casual coordination",
        "text": "Hey, running about 10 minutes late due to traffic. Grab a table inside if you are already there.",
        "expected_intent": "Ham (Casual)",
    },
]


def run_robustness_checks(pipeline) -> pd.DataFrame:
    """
    Evaluates the pipeline on the curated robustness test suite.
    Returns a structured DataFrame for inspection and presentation.
    """
    records = []
    for case in ROBUSTNESS_TEST_CASES:
        text = case["text"]
        pred_label_idx = pipeline.predict([text])[0]
        pred_label = "SPAM" if pred_label_idx == 1 else "HAM"

        proba_spam = None
        if hasattr(pipeline, "predict_proba"):
            proba_spam = round(float(pipeline.predict_proba([text])[0][1]), 4)

        # Diagnose outcome
        if case["expected_intent"].startswith("Ham") and pred_label == "SPAM":
            outcome = "FALSE POSITIVE (Failed: Legitimate flagged as Spam)"
        elif case["expected_intent"].startswith("Spam") and pred_label == "HAM":
            outcome = "FALSE NEGATIVE (Failed: Obfuscated Spam slipped through)"
        else:
            outcome = "CORRECT (Robust on this sample)"

        records.append({
            "Category": case["category"],
            "Description": case["description"],
            "Test Text": text,
            "Expected Intent": case["expected_intent"],
            "Model Prediction": pred_label,
            "P(Spam)": proba_spam,
            "Diagnosis": outcome,
        })

    return pd.DataFrame(records)
