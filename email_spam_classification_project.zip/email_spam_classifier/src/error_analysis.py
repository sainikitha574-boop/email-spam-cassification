"""
error_analysis.py - Safe inspection and linguistic diagnosis of classification errors.

Privacy Principle:
All message text passed through error analysis is automatically sanitized using
`redact_pii()` to prevent any exposure of private phone numbers, names, or credentials.
"""

from typing import List, Dict, Any
import numpy as np
import pandas as pd
from .dataset import redact_pii


def extract_misclassifications(
    pipeline,
    X_test: pd.Series,
    y_test: pd.Series,
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Identifies False Positives (Ham predicted as Spam) and
    False Negatives (Spam predicted as Ham) on the test set.
    """
    y_pred = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)[:, 1] if hasattr(pipeline, "predict_proba") else [None] * len(y_test)

    fps = []
    fns = []

    for idx, (text, true_y, pred_y, proba) in enumerate(zip(X_test, y_test, y_pred, y_proba)):
        clean_text = redact_pii(text)

        if true_y == 0 and pred_y == 1:
            fps.append({
                "test_index": idx,
                "true_label": "ham (legitimate)",
                "predicted_label": "SPAM",
                "spam_probability": round(float(proba), 4) if proba is not None else "N/A",
                "sanitized_text": clean_text,
            })
        elif true_y == 1 and pred_y == 0:
            fns.append({
                "test_index": idx,
                "true_label": "spam",
                "predicted_label": "HAM (legitimate)",
                "spam_probability": round(float(proba), 4) if proba is not None else "N/A",
                "sanitized_text": clean_text,
            })

    return {"false_positives": fps, "false_negatives": fns}


def generate_error_report(misclassifications: Dict[str, List[Dict[str, Any]]]) -> str:
    """
    Produces a formatted text report analyzing why errors occurred.
    """
    fps = misclassifications["false_positives"]
    fns = misclassifications["false_negatives"]

    report = []
    report.append("=" * 70)
    report.append("SAFE ERROR ANALYSIS REPORT (PII REDACTED)")
    report.append("=" * 70)
    report.append(f"\nTotal False Positives (Legitimate flagged as Spam): {len(fps)}")
    report.append(f"Total False Negatives (Spam missed into Inbox): {len(fns)}\n")

    report.append("-" * 70)
    report.append("1. REPRESENTATIVE FALSE POSITIVES (HIGH COST ERRORS)")
    report.append("Why did the model mistakenly flag legitimate messages?")
    report.append("-" * 70)

    if not fps:
        report.append("Zero False Positives observed on the test set!")
    else:
        for i, item in enumerate(fps[:5], 1):
            report.append(f"\n[FP Case #{i}] P(Spam) = {item['spam_probability']}")
            report.append(f"Text: \"{item['sanitized_text']}\"")
            report.append("Diagnostic Note: Likely contains promotional or transactional keywords")
            report.append("(e.g., urgent, free, call, account, cash, prize) used in benign context.")

    report.append("\n" + "-" * 70)
    report.append("2. REPRESENTATIVE FALSE NEGATIVES (MISSED SPAM)")
    report.append("Why did the spam message slip past the filter?")
    report.append("-" * 70)

    if not fns:
        report.append("Zero False Negatives observed on the test set!")
    else:
        for i, item in enumerate(fns[:5], 1):
            report.append(f"\n[FN Case #{i}] P(Spam) = {item['spam_probability']}")
            report.append(f"Text: \"{item['sanitized_text']}\"")
            report.append("Diagnostic Note: Spam message lacks standard high-frequency spam tokens,")
            report.append("uses subtle phrasing, or relies on conversational deception.")

    report.append("\n" + "=" * 70)
    return "\n".join(report)
