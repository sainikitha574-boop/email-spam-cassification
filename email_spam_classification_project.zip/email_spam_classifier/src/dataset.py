"""
dataset.py - Dataset loading, exploration, and privacy redaction.

Citation:
Almeida, T.A., Gomez Hidalgo, J.M., & Yamakami, A. (2012).
SMS Spam Collection. UCI Machine Learning Repository.
DOI: 10.24432/C5CC84
https://archive.ics.uci.edu/dataset/228/sms+spam+collection
"""

import os
import re
import pandas as pd
import numpy as np


def load_raw_dataset(data_path: str = None) -> pd.DataFrame:
    """
    Loads the SMS Spam Collection dataset from disk.
    Supports tab-delimited raw file or CSV fallbacks.
    """
    if data_path is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        data_path = os.path.join(base_dir, "data", "SMSSpamCollection")

    if not os.path.exists(data_path):
        raise FileNotFoundError(
            f"Dataset not found at {data_path}. Please check data directory."
        )

    # Attempt utf-8 first, fallback to latin-1
    try:
        df = pd.read_csv(data_path, sep="\t", header=None, names=["label", "text"], encoding="utf-8")
    except (UnicodeDecodeError, Exception):
        df = pd.read_csv(data_path, sep="\t", header=None, names=["label", "text"], encoding="latin-1")

    # Standardize column types
    df["label"] = df["label"].astype(str).str.strip().str.lower()
    df["text"] = df["text"].astype(str).str.strip()

    return df


def redact_pii(text: str) -> str:
    """
    Redacts phone numbers, email addresses, and specific URLs to safely
    inspect messages without exposing personal identifiable information (PII).
    """
    # Redact email addresses
    redacted = re.sub(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+", "[EMAIL_REDACTED]", text)
    # Redact phone numbers / long numeric strings (>=7 digits or common phone formats)
    redacted = re.sub(r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{3,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{3,4}", "[PHONE_REDACTED]", redacted)
    # Redact standalone 5-11 digit numbers (often shortcodes or pin numbers)
    redacted = re.sub(r"\b\d{5,11}\b", "[NUM_REDACTED]", redacted)
    # Redact full URLs
    redacted = re.sub(r"https?://[^\s]+|www\.[^\s]+", "[URL_REDACTED]", redacted)
    return redacted


def run_eda(df: pd.DataFrame, drop_duplicates: bool = False) -> dict:
    """
    Performs Exploratory Data Analysis (EDA) on the dataset.
    Returns a dictionary of summary statistics and prints a clear report.
    """
    total_raw = len(df)
    missing_labels = df["label"].isnull().sum()
    missing_texts = (df["text"].str.len() == 0).sum()
    duplicates_count = df.duplicated(subset=["text"]).sum()

    # Calculate length metrics
    df_calc = df.copy()
    df_calc["char_len"] = df_calc["text"].apply(len)
    df_calc["word_count"] = df_calc["text"].apply(lambda s: len(s.split()))

    class_counts = df_calc["label"].value_counts().to_dict()
    class_pct = (df_calc["label"].value_counts(normalize=True) * 100).to_dict()

    # Privacy audit counts
    has_phone = df_calc["text"].apply(lambda t: bool(re.search(r"\b\d{7,11}\b", t))).sum()
    has_url = df_calc["text"].apply(lambda t: bool(re.search(r"https?://|www\.|\.co\.uk|\.com", t.lower()))).sum()

    stats_by_class = {}
    for lbl in ["ham", "spam"]:
        sub = df_calc[df_calc["label"] == lbl]
        stats_by_class[lbl] = {
            "count": len(sub),
            "pct": float(class_pct.get(lbl, 0.0)),
            "char_mean": float(sub["char_len"].mean()),
            "char_median": float(sub["char_len"].median()),
            "word_mean": float(sub["word_count"].mean()),
            "word_median": float(sub["word_count"].median()),
        }

    summary = {
        "total_records": total_raw,
        "missing_labels": int(missing_labels),
        "missing_texts": int(missing_texts),
        "duplicate_texts": int(duplicates_count),
        "duplicate_pct": float(duplicates_count / total_raw * 100),
        "stats_by_class": stats_by_class,
        "privacy_audit": {
            "messages_with_phone_or_code": int(has_phone),
            "messages_with_url_indicator": int(has_url),
        },
    }

    return summary


def get_prepared_data(drop_duplicates: bool = True) -> pd.DataFrame:
    """
    Returns clean dataframe with binary numeric target:
    ham -> 0 (negative/legitimate)
    spam -> 1 (positive/spam)

    Why deduplicate?
    Deduplicating prevents exact duplicates from leaking between train and test splits.
    If an exact identical spam blast exists in both sets, testing on memorized text
    falsely inflates model evaluation.
    """
    df = load_raw_dataset()

    if drop_duplicates:
        df = df.drop_duplicates(subset=["text"]).reset_index(drop=True)

    # Encode binary labels explicitly
    df["target"] = df["label"].map({"ham": 0, "spam": 1})

    return df
