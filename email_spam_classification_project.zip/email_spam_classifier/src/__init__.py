"""
Email/SMS Spam Classification with NLP
Package initialization
"""
