"""
evaluate.py - Evaluation metrics, cross-validation, and confusion matrix analysis.

Evaluation Philosophy & The Asymmetric Cost of False Positives:
In spam filtering:
- Positive Class = 1 (SPAM)
- Negative Class = 0 (HAM / Legitimate)

A False Positive (FP) occurs when a legitimate message is incorrectly classified as SPAM.
Cost: Very High. The user may miss an urgent job offer, a legal document, a flight
cancellation, or medical test results because it landed in the junk folder or was blocked.

A False Negative (FN) occurs when an actual spam message is classified as HAM.
Cost: Low to Moderate. An annoying promotional message or scam lands in the user's inbox,
wasting a few seconds of attention.

Therefore, spam filter design prioritizes HIGH PRECISION (minimizing False Positives)
even if it means accepting a slightly lower Recall.
"""

from typing import Dict, Any, Tuple
import numpy as np
import pandas as pd
from sklearn.metrics import (
    precision_score,
    recall_score,
    f1_score,
    accuracy_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
)
from sklearn.model_selection import StratifiedKFold, cross_validate


def evaluate_predictions(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: np.ndarray = None,
    pos_label: int = 1,
) -> Dict[str, Any]:
    """
    Computes standard classification metrics with explicit positive class = SPAM (1).
    Averaging is binary, evaluating the model's ability to catch spam while avoiding false positives.
    """
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()

    precision = precision_score(y_true, y_pred, pos_label=pos_label, zero_division=0)
    recall = recall_score(y_true, y_pred, pos_label=pos_label, zero_division=0)
    f1 = f1_score(y_true, y_pred, pos_label=pos_label, zero_division=0)
    acc = accuracy_score(y_true, y_pred)

    # Specificity = True Negative Rate (Ham correctly identified)
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    # False Positive Rate = FP / (FP + TN)
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

    metrics = {
        "accuracy": float(acc),
        "precision_spam": float(precision),
        "recall_spam": float(recall),
        "f1_spam": float(f1),
        "specificity_ham": float(specificity),
        "false_positive_rate": float(fpr),
        "confusion_matrix": {
            "TN": int(tn),  # Ham correctly kept in Inbox
            "FP": int(fp),  # Ham mistakenly sent to Spam (CRITICAL ERROR)
            "FN": int(fn),  # Spam missed and sent to Inbox
            "TP": int(tp),  # Spam caught correctly
        },
    }

    if y_proba is not None:
        try:
            metrics["roc_auc"] = float(roc_auc_score(y_true, y_proba))
        except Exception:
            metrics["roc_auc"] = None

    return metrics


def run_cross_validation(
    pipeline,
    X_train: pd.Series,
    y_train: pd.Series,
    cv_folds: int = 5,
    random_state: int = 42,
) -> Dict[str, float]:
    """
    Runs Stratified K-Fold Cross-Validation on the training set ONLY.
    Guarantees no test set leakage during validation.
    """
    skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=random_state)
    scoring = {
        "accuracy": "accuracy",
        "precision": "precision",
        "recall": "recall",
        "f1": "f1",
        "roc_auc": "roc_auc",
    }

    cv_results = cross_validate(pipeline, X_train, y_train, cv=skf, scoring=scoring)

    summary = {
        "cv_accuracy_mean": float(np.mean(cv_results["test_accuracy"])),
        "cv_accuracy_std": float(np.std(cv_results["test_accuracy"])),
        "cv_precision_mean": float(np.mean(cv_results["test_precision"])),
        "cv_precision_std": float(np.std(cv_results["test_precision"])),
        "cv_recall_mean": float(np.mean(cv_results["test_recall"])),
        "cv_recall_std": float(np.std(cv_results["test_recall"])),
        "cv_f1_mean": float(np.mean(cv_results["test_f1"])),
        "cv_f1_std": float(np.std(cv_results["test_f1"])),
        "cv_roc_auc_mean": float(np.mean(cv_results["test_roc_auc"])),
        "cv_roc_auc_std": float(np.std(cv_results["test_roc_auc"])),
    }

    return summary


def threshold_tradeoff_analysis(
    pipeline,
    X_val: pd.Series,
    y_val: pd.Series,
    thresholds: list = None,
) -> pd.DataFrame:
    """
    Analyzes how shifting decision threshold theta (predict spam if P(spam) >= theta)
    trades off False Positives vs Recall.
    """
    if thresholds is None:
        thresholds = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95]

    y_proba = pipeline.predict_proba(X_val)[:, 1]
    rows = []

    for t in thresholds:
        preds = (y_proba >= t).astype(int)
        tn, fp, fn, tp = confusion_matrix(y_val, preds, labels=[0, 1]).ravel()
        prec = precision_score(y_val, preds, pos_label=1, zero_division=0)
        rec = recall_score(y_val, preds, pos_label=1, zero_division=0)
        f1 = f1_score(y_val, preds, pos_label=1, zero_division=0)

        rows.append({
            "threshold": t,
            "false_positives (FP)": fp,
            "false_negatives (FN)": fn,
            "precision (spam)": round(prec, 4),
            "recall (spam)": round(rec, 4),
            "f1_score (spam)": round(f1, 4),
        })

    return pd.DataFrame(rows)
