"""
demo.py - Interactive spam-checker demonstration with transparency cautions.

Safety & Educational Disclaimer:
Predictions and confidence probabilities from this educational classifier are
statistical estimates based on historical training data. A 99% probability is NOT
a cryptographic or factual guarantee. Any automated system can produce false positives
(blocking legitimate messages) or false negatives (letting deceptive spam through).
"""

from typing import Dict, Any
import numpy as np


def predict_message(pipeline, raw_text: str) -> Dict[str, Any]:
    """
    Predicts whether a user-submitted message is Spam or Ham,
    providing probability, risk level, and transparent caution notices.
    """
    if not raw_text or not raw_text.strip():
        return {
            "error": "Empty text provided. Please enter a valid message.",
            "label": None,
            "confidence": None,
        }

    clean_input = raw_text.strip()
    prediction_idx = pipeline.predict([clean_input])[0]
    predicted_label = "SPAM" if prediction_idx == 1 else "HAM (Legitimate)"

    proba_spam = None
    proba_ham = None
    if hasattr(pipeline, "predict_proba"):
        probabilities = pipeline.predict_proba([clean_input])[0]
        proba_ham = float(probabilities[0])
        proba_spam = float(probabilities[1])

    # Assess decision certainty and risk of False Positive
    if proba_spam is not None:
        if proba_spam >= 0.85:
            risk_tier = "High Spam Probability"
            guidance = "Strong indicators of spam/promotional patterns detected."
        elif proba_spam >= 0.50:
            risk_tier = "Moderate Spam Probability (Borderline)"
            guidance = "Mild spam indicators detected. Caution: Higher risk of False Positive if this is personal or work-related."
        elif proba_spam >= 0.20:
            risk_tier = "Low Spam Probability (Borderline Ham)"
            guidance = "Appears mostly legitimate, but contains ambiguous or transactional keywords."
        else:
            risk_tier = "Very Low Spam Probability (Likely Clean)"
            guidance = "Consistent with ordinary legitimate correspondence."
    else:
        risk_tier = "Standard Prediction"
        guidance = "Binary prediction without calibrated probability."

    caution_message = (
        "IMPORTANT NOTICE: A statistical model prediction is an estimate, NOT a guarantee. "
        "Predictions can be wrong. Legitimate messages containing promotional words "
        "(e.g., 'free', 'urgent', 'winner', discounts) may be incorrectly flagged (False Positive). "
        "Never rely solely on an isolated NLP model for security-critical decisions."
    )

    return {
        "input_text": clean_input,
        "predicted_label": predicted_label,
        "probability_spam": round(proba_spam, 4) if proba_spam is not None else "N/A",
        "probability_ham": round(proba_ham, 4) if proba_ham is not None else "N/A",
        "confidence_percentage": f"{max(proba_spam or 0, proba_ham or 0) * 100:.2f}%",
        "risk_tier": risk_tier,
        "guidance": guidance,
        "caution_disclaimer": caution_message,
    }


def interactive_terminal_demo(pipeline):
    """
    Runs an interactive terminal loop where the user can paste any message.
    """
    print("\n" + "=" * 65)
    print("      INTERACTIVE EMAIL/SMS SPAM CHECKER DEMO")
    print("=" * 65)
    print("Type or paste any message below to inspect its classification.")
    print("Type 'exit' or 'quit' to end the session.\n")

    while True:
        try:
            user_input = input("\nEnter message to check > ")
            if user_input.strip().lower() in ["exit", "quit"]:
                print("Exiting interactive demo. Thank you!")
                break

            result = predict_message(pipeline, user_input)
            if "error" in result and result.get("label") is None:
                print(f"[!] {result['error']}")
                continue

            print("\n" + "-" * 50)
            print(f"PREDICTED LABEL : {result['predicted_label']}")
            print(f"SPAM PROBABILITY: {result['probability_spam']} ({result['confidence_percentage']} confidence)")
            print(f"ASSESSMENT      : {result['risk_tier']}")
            print(f"EXPLANATION     : {result['guidance']}")
            print("-" * 50)
            print(f"[!] {result['caution_disclaimer']}")
            print("-" * 50)

        except (KeyboardInterrupt, EOFError):
            print("\nExiting demo.")
            break


if __name__ == "__main__":
    import joblib
    import os

    model_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "models",
        "best_spam_pipeline.joblib",
    )
    if os.path.exists(model_path):
        pipe = joblib.load(model_path)
        interactive_terminal_demo(pipe)
    else:
        print(f"Model file not found at {model_path}. Please run run_experiments.py first.")
