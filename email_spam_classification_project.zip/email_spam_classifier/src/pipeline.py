"""
pipeline.py - Scikit-Learn Pipelines for Leakage-Free NLP Modeling.

Why Pipelines Prevent Data Leakage:
Fitting a vectorizer (like CountVectorizer or TfidfVectorizer) on the entire dataset
before splitting exposes vocabulary frequencies and inverse document frequencies (IDF)
from the test set to the model. Using a Pipeline ensures that vectorizers are fit ONLY
on the training data (or training folds during cross-validation), leaving the test set
completely untouched until final evaluation.
"""

from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier


def get_baseline_pipeline() -> Pipeline:
    """
    Simple baseline: Standard CountVectorizer (bag of words) with Multinomial Naive Bayes.
    """
    return Pipeline([
        ("vectorizer", CountVectorizer(lowercase=True)),
        ("classifier", MultinomialNB(alpha=1.0)),
    ])


def get_multinomial_nb_pipeline(
    use_tfidf: bool = True,
    ngram_range: tuple = (1, 1),
    stop_words: str = None,
    sublinear_tf: bool = False,
    alpha: float = 1.0,
) -> Pipeline:
    """
    Multinomial Naive Bayes Pipeline with configurable vectorizer options.
    """
    if use_tfidf:
        vec = TfidfVectorizer(
            lowercase=True,
            ngram_range=ngram_range,
            stop_words=stop_words,
            sublinear_tf=sublinear_tf,
        )
    else:
        vec = CountVectorizer(
            lowercase=True,
            ngram_range=ngram_range,
            stop_words=stop_words,
        )

    return Pipeline([
        ("vectorizer", vec),
        ("classifier", MultinomialNB(alpha=alpha)),
    ])


def get_logistic_regression_pipeline(
    use_tfidf: bool = True,
    ngram_range: tuple = (1, 1),
    stop_words: str = None,
    sublinear_tf: bool = False,
    C: float = 1.0,
    max_iter: int = 1000,
    random_state: int = 42,
) -> Pipeline:
    """
    Logistic Regression Pipeline with configurable vectorizer and regularizer.
    """
    if use_tfidf:
        vec = TfidfVectorizer(
            lowercase=True,
            ngram_range=ngram_range,
            stop_words=stop_words,
            sublinear_tf=sublinear_tf,
        )
    else:
        vec = CountVectorizer(
            lowercase=True,
            ngram_range=ngram_range,
            stop_words=stop_words,
        )

    return Pipeline([
        ("vectorizer", vec),
        ("classifier", LogisticRegression(
            C=C,
            max_iter=max_iter,
            random_state=random_state,
            class_weight=None,  # Standard baseline; can also be evaluated with 'balanced'
        )),
    ])


def get_dummy_baseline_pipeline(strategy: str = "most_frequent") -> Pipeline:
    """
    Dummy classifier baseline (e.g. always predicting majority class 'ham').
    Highlights why raw accuracy is deceptive on imbalanced datasets.
    """
    return Pipeline([
        ("vectorizer", CountVectorizer()),
        ("classifier", DummyClassifier(strategy=strategy)),
    ])
