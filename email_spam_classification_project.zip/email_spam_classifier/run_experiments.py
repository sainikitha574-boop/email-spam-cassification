"""
run_experiments.py - Complete, reproducible experimental pipeline.

Executes all 11 requirements:
1. Dataset loading & EDA
2. Zero-leakage train/test split
3. Baseline & pipeline comparison (MultinomialNB vs LogisticRegression)
4. Stratified 5-Fold Cross-Validation on training data
5. Test set evaluation (Precision, Recall, F1, Confusion Matrix, FP cost analysis)
6. Preprocessing choice comparisons (Stopwords, N-grams, Sublinear TF)
7. Threshold tuning trade-off analysis
8. Safe error analysis with PII redaction
9. Robustness checks demonstration
10. Model persistence for demo
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

from src.dataset import load_raw_dataset, run_eda, get_prepared_data
from src.pipeline import (
    get_baseline_pipeline,
    get_multinomial_nb_pipeline,
    get_logistic_regression_pipeline,
    get_dummy_baseline_pipeline,
)
from src.evaluate import (
    evaluate_predictions,
    run_cross_validation,
    threshold_tradeoff_analysis,
)
from src.error_analysis import extract_misclassifications, generate_error_report
from src.robustness import run_robustness_checks


def main():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    reports_dir = os.path.join(base_dir, "reports")
    models_dir = os.path.join(base_dir, "models")
    os.makedirs(reports_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)

    print("=" * 70)
    print("STEP 1 & 2: LOADING DATASET & EXPLORATORY DATA ANALYSIS (EDA)")
    print("=" * 70)
    raw_df = load_raw_dataset()
    eda_summary = run_eda(raw_df)

    print(f"Total raw messages: {eda_summary['total_records']}")
    print(f"Missing labels: {eda_summary['missing_labels']}, Missing text: {eda_summary['missing_texts']}")
    print(f"Duplicate messages: {eda_summary['duplicate_texts']} ({eda_summary['duplicate_pct']:.2f}%)")
    print("\nClass Distribution:")
    for lbl, stats in eda_summary["stats_by_class"].items():
        print(f"  [{lbl.upper()}]: {stats['count']} messages ({stats['pct']:.2f}%) | "
              f"Avg char length: {stats['char_mean']:.1f} | Avg words: {stats['word_mean']:.1f}")

    # Save EDA summary
    with open(os.path.join(reports_dir, "eda_summary.json"), "w") as f:
        json.dump(eda_summary, f, indent=2)

    print("\n" + "=" * 70)
    print("STEP 3: TRAIN / TEST SPLIT (PREVENTING DATA LEAKAGE)")
    print("=" * 70)
    # Deduplicate before splitting to avoid testing on memorized messages
    clean_df = get_prepared_data(drop_duplicates=True)
    print(f"Clean deduplicated records: {len(clean_df)}")
    print(f"Class counts after deduplication:\n{clean_df['label'].value_counts().to_string()}")

    X = clean_df["text"]
    y = clean_df["target"]  # 0 = ham, 1 = spam

    # Crucial: Split BEFORE fitting any vectorizer or preprocessor
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )
    print(f"\nTrain set: {len(X_train)} samples ({y_train.sum()} spam, {len(y_train) - y_train.sum()} ham)")
    print(f"Test set : {len(X_test)} samples ({y_test.sum()} spam, {len(y_test) - y_test.sum()} ham)")
    print("[v] Verification: Split was performed before any vectorizer fitting. Zero data leakage.")

    print("\n" + "=" * 70)
    print("STEP 4 & 5: MODEL TRAINING & 5-FOLD CROSS-VALIDATION ON TRAIN SET")
    print("=" * 70)

    candidate_pipelines = {
        "Dummy (Most Frequent)": get_dummy_baseline_pipeline(strategy="most_frequent"),
        "CountVec + MultinomialNB (Baseline)": get_baseline_pipeline(),
        "TF-IDF + MultinomialNB": get_multinomial_nb_pipeline(use_tfidf=True),
        "CountVec + LogisticRegression": get_logistic_regression_pipeline(use_tfidf=False),
        "TF-IDF + LogisticRegression": get_logistic_regression_pipeline(use_tfidf=True, C=1.0),
    }

    cv_results_table = []
    for name, pipe in candidate_pipelines.items():
        print(f"Running 5-fold CV on train set: {name}...")
        cv_res = run_cross_validation(pipe, X_train, y_train, cv_folds=5, random_state=42)
        cv_results_table.append({
            "Model": name,
            "CV_Accuracy": f"{cv_res['cv_accuracy_mean']:.4f} ± {cv_res['cv_accuracy_std']:.4f}",
            "CV_Precision_Spam": f"{cv_res['cv_precision_mean']:.4f} ± {cv_res['cv_precision_std']:.4f}",
            "CV_Recall_Spam": f"{cv_res['cv_recall_mean']:.4f} ± {cv_res['cv_recall_std']:.4f}",
            "CV_F1_Spam": f"{cv_res['cv_f1_mean']:.4f} ± {cv_res['cv_f1_std']:.4f}",
            "CV_ROC_AUC": f"{cv_res['cv_roc_auc_mean']:.4f} ± {cv_res['cv_roc_auc_std']:.4f}",
            "_f1_mean": cv_res["cv_f1_mean"],
            "_prec_mean": cv_res["cv_precision_mean"],
        })

    cv_df = pd.DataFrame(cv_results_table)
    print("\n--- Cross-Validation Results on Training Set ---")
    display_cols = ["Model", "CV_Accuracy", "CV_Precision_Spam", "CV_Recall_Spam", "CV_F1_Spam", "CV_ROC_AUC"]
    print(cv_df[display_cols].to_string(index=False))

    print("\n" + "=" * 70)
    print("STEP 6: FINAL EVALUATION ON UNTOUCHED TEST SET")
    print("=" * 70)
    print("Positive class = SPAM (1), Negative class = HAM (0)")
    print("Analyzing False Positives (Legitimate emails blocked) and False Negatives (Missed spam)\n")

    test_eval_records = []
    fitted_models = {}

    for name, pipe in candidate_pipelines.items():
        pipe.fit(X_train, y_train)
        fitted_models[name] = pipe

        y_pred = pipe.predict(X_test)
        y_proba = pipe.predict_proba(X_test)[:, 1] if hasattr(pipe, "predict_proba") else None

        metrics = evaluate_predictions(y_test.values, y_pred, y_proba)
        cm = metrics["confusion_matrix"]

        test_eval_records.append({
            "Model": name,
            "Accuracy": metrics["accuracy"],
            "Precision (Spam)": metrics["precision_spam"],
            "Recall (Spam)": metrics["recall_spam"],
            "F1-Score (Spam)": metrics["f1_spam"],
            "Specificity (Ham)": metrics["specificity_ham"],
            "ROC-AUC": metrics["roc_auc"],
            "TN (Clean Inbox)": cm["TN"],
            "FP (Ham Blocked)": cm["FP"],
            "FN (Spam Missed)": cm["FN"],
            "TP (Spam Caught)": cm["TP"],
        })

    test_df = pd.DataFrame(test_eval_records)
    print(test_df[["Model", "Precision (Spam)", "Recall (Spam)", "F1-Score (Spam)", "FP (Ham Blocked)", "FN (Spam Missed)"]].to_string(index=False))

    # Save test results
    test_df.to_csv(os.path.join(reports_dir, "model_comparison.csv"), index=False)

    # Select best model for false positive control & production
    # In spam filtering, we prioritize high precision (minimal FP) while maintaining strong recall
    best_model_name = "TF-IDF + MultinomialNB"
    best_pipe = fitted_models[best_model_name]
    joblib.dump(best_pipe, os.path.join(models_dir, "best_spam_pipeline.joblib"))
    print(f"\n[v] Saved best pipeline ({best_model_name}) to models/best_spam_pipeline.joblib")

    # Plot Confusion Matrix
    fig, ax = plt.subplots(figsize=(6, 5))
    cm_best = confusion_matrix(y_test, best_pipe.predict(X_test), labels=[0, 1])
    disp = ConfusionMatrixDisplay(
        confusion_matrix=cm_best,
        display_labels=["Ham (Inbox)", "Spam (Filtered)"]
    )
    disp.plot(ax=ax, cmap="Blues", values_format="d")
    plt.title(f"Confusion Matrix: {best_model_name}\n(Focus: Minimize False Positives in Top-Right)")
    plt.tight_layout()
    cm_path = os.path.join(reports_dir, "confusion_matrix.png")
    plt.savefig(cm_path, dpi=200)
    plt.close()
    print(f"[v] Saved confusion matrix visualization to {cm_path}")

    print("\n" + "=" * 70)
    print("STEP 7: SAFE ERROR ANALYSIS (PII REDACTED)")
    print("=" * 70)
    misclass = extract_misclassifications(best_pipe, X_test, y_test)
    error_report_text = generate_error_report(misclass)
    print(error_report_text)

    with open(os.path.join(reports_dir, "error_analysis_redacted.txt"), "w", encoding="utf-8") as f:
        f.write(error_report_text)

    print("\n" + "=" * 70)
    print("STEP 8: PREPROCESSING & FEATURE ENGINEERING EXPERIMENTS")
    print("=" * 70)
    print("Fair comparison on training set: Recording impact of each modification...")

    prep_variants = {
        "Default (TF-IDF, Unigrams, No Stopwords)": get_multinomial_nb_pipeline(
            use_tfidf=True, ngram_range=(1, 1), stop_words=None, sublinear_tf=False
        ),
        "Variant A (+ Stopword Removal)": get_multinomial_nb_pipeline(
            use_tfidf=True, ngram_range=(1, 1), stop_words="english", sublinear_tf=False
        ),
        "Variant B (+ Bigrams (1, 2))": get_multinomial_nb_pipeline(
            use_tfidf=True, ngram_range=(1, 2), stop_words=None, sublinear_tf=False
        ),
        "Variant C (+ Sublinear TF Scaling)": get_multinomial_nb_pipeline(
            use_tfidf=True, ngram_range=(1, 1), stop_words=None, sublinear_tf=True
        ),
        "Variant D (+ Bigrams + Stopwords)": get_multinomial_nb_pipeline(
            use_tfidf=True, ngram_range=(1, 2), stop_words="english", sublinear_tf=False
        ),
    }

    prep_records = []
    base_f1 = None
    for vname, vpipe in prep_variants.items():
        vcv = run_cross_validation(vpipe, X_train, y_train, cv_folds=5)
        f1_m = vcv["cv_f1_mean"]
        if base_f1 is None:
            base_f1 = f1_m
            impact = "Baseline Reference"
        else:
            diff = f1_m - base_f1
            impact = f"{'+' if diff >= 0 else ''}{diff:.4f} F1 ({'Improved' if diff > 0 else 'Worsened' if diff < 0 else 'Neutral'})"

        prep_records.append({
            "Preprocessing Choice": vname,
            "CV_F1_Spam": f"{f1_m:.4f}",
            "CV_Precision": f"{vcv['cv_precision_mean']:.4f}",
            "CV_Recall": f"{vcv['cv_recall_mean']:.4f}",
            "Relative Impact": impact,
        })

    prep_df = pd.DataFrame(prep_records)
    print(prep_df.to_string(index=False))
    prep_df.to_csv(os.path.join(reports_dir, "preprocessing_comparison.csv"), index=False)

    print("\n" + "=" * 70)
    print("STEP 8B: THRESHOLD TUNING ANALYSIS (CONTROLLING FALSE POSITIVES)")
    print("=" * 70)
    threshold_df = threshold_tradeoff_analysis(best_pipe, X_test, y_test)
    print(threshold_df.to_string(index=False))
    threshold_df.to_csv(os.path.join(reports_dir, "threshold_analysis.csv"), index=False)

    print("\n" + "=" * 70)
    print("STEP 9: QUALITATIVE ROBUSTNESS CHECKS")
    print("=" * 70)
    print("Disclaimer: Qualitative demonstration of edge cases, NOT a formal adversarial evaluation.")
    rob_df = run_robustness_checks(best_pipe)
    print(rob_df[["Category", "Expected Intent", "Model Prediction", "P(Spam)", "Diagnosis"]].to_string(index=False))
    rob_df.to_csv(os.path.join(reports_dir, "robustness_results.csv"), index=False)

    print("\n" + "=" * 70)
    print("ALL EXPERIMENTS COMPLETED SUCCESSFULLY!")
    print(f"Artifacts saved in: {reports_dir}")
    print("=" * 70)


if __name__ == "__main__":
    main()
