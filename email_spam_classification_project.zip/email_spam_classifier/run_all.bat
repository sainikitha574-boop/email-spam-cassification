@echo off
echo ========================================================
echo   Email & SMS Spam Classification with NLP
echo   Running Complete Experimental Pipeline
echo ========================================================
echo.

python --version
if errorlevel 1 (
    echo [ERROR] Python is not installed or not in your PATH.
    pause
    exit /b
)

echo [1/3] Installing/verifying dependencies...
pip install -r requirements.txt

echo.
echo [2/3] Running end-to-end experiments...
python run_experiments.py

echo.
echo [3/3] Generating clean Jupyter notebook...
python generate_notebook.py

echo.
echo ========================================================
echo   Experiments Finished Successfully!
echo   Reports and plots saved in the 'reports/' folder.
echo   To launch the web demo, run: python app.py
echo ========================================================
pause
