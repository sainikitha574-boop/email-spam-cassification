"""
app.py - Lightweight local web server for interactive spam-checker demonstration.
Uses Python's standard library http.server (no extra web framework dependencies required!).
"""

import os
import json
import joblib
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

from src.demo import predict_message

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "models", "best_spam_pipeline.joblib")

# Load model pipeline into memory
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"Model not found at {MODEL_PATH}. Run run_experiments.py first.")

pipeline = joblib.load(MODEL_PATH)
print(f"[v] Loaded model pipeline from {MODEL_PATH}")


class SpamDemoRequestHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path in ["/", "/index.html"]:
            self.path = "/web_demo.html"
            return super().do_GET()
        return super().do_GET()

    def do_POST(self):
        if self.path == "/api/predict":
            content_length = int(self.headers.get("Content-Length", 0))
            post_body = self.rfile.read(content_length)

            try:
                data = json.loads(post_body.decode("utf-8"))
                text = data.get("text", "")
                result = predict_message(pipeline, text)

                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.end_headers()
                self.wfile.write(json.dumps(result).encode("utf-8"))
            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()


def run_server(port: int = 8080):
    server_address = ("", port)
    httpd = HTTPServer(server_address, SpamDemoRequestHandler)
    print("=" * 65)
    print(f"  Spam Classification Interactive Web Demo Running!")
    print(f"  URL: http://localhost:{port}/")
    print("  Press Ctrl+C to stop the server.")
    print("=" * 65)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server.")
        httpd.server_close()


if __name__ == "__main__":
    run_server(port=8080)
