"""
generate_notebook.py - Generates the complete step-by-step Jupyter Notebook.
"""

import json
import os

nb = {
    "cells": [
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "# Email & SMS Spam Classification with NLP\n",
                "### Research Question: *Can a text classifier distinguish spam from legitimate email while making false positives easy to understand?*\n",
                "\n",
                "---\n",
                "## Project Overview & Objectives\n",
                "Spam filtering is one of the classic, real-world applications of Natural Language Processing (NLP). However, in production spam filtering, **not all errors are created equal**:\n",
                "- **False Positive (FP)**: A legitimate email/message is misclassified as SPAM. Cost: **Very High** (a user misses a critical job offer, flight alert, or legal document).\n",
                "- **False Negative (FN)**: A spam message slips into the inbox. Cost: **Low to Moderate** (minor annoyance).\n",
                "\n",
                "In this project, we build a complete, leakage-free NLP pipeline in `scikit-learn`, evaluate multiple classifiers, analyze false positives safely, test edge-case robustness, and create an interactive checker demo."
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 1: Dataset Selection, Citation & Ethics\n",
                "- **Dataset**: UCI SMS Spam Collection\n",
                "- **Citation**: Almeida, T.A., Gomez Hidalgo, J.M., & Yamakami, A. (2012). *SMS Spam Collection*. UCI Machine Learning Repository. [DOI: 10.24432/C5CC84](https://archive.ics.uci.edu/dataset/228/sms+spam+collection).\n",
                "- **Labels**: `ham` (legitimate) and `spam` (unsolicited commercial/scam).\n",
                "- **Limitations**: SMS character limits (~160 chars), mobile abbreviations, lack of email headers/DKIM.\n",
                "- **Privacy**: Contains real phone numbers and names from consumer complaints. We redact all PII before inspecting."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "import os, sys, re\n",
                "import pandas as pd\n",
                "import numpy as np\n",
                "import matplotlib.pyplot as plt\n",
                "from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate\n",
                "from sklearn.pipeline import Pipeline\n",
                "from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer\n",
                "from sklearn.naive_bayes import MultinomialNB\n",
                "from sklearn.linear_model import LogisticRegression\n",
                "from sklearn.dummy import DummyClassifier\n",
                "from sklearn.metrics import classification_report, confusion_matrix, ConfusionMatrixDisplay, precision_score, recall_score, f1_score\n",
                "\n",
                "print(\"All libraries successfully imported!\")"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 2: Exploratory Data Analysis (EDA)\n",
                "We inspect class distribution, check for missing values, analyze duplicates, and compare text lengths."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "data_path = '../data/SMSSpamCollection'\n",
                "df = pd.read_csv(data_path, sep='\\t', header=None, names=['label', 'text'], encoding='utf-8')\n",
                "\n",
                "print(f'Total raw samples: {len(df)}')\n",
                "print('\\nMissing values:')\n",
                "print(df.isnull().sum())\n",
                "\n",
                "print('\\nClass Distribution:')\n",
                "print(df['label'].value_counts())\n",
                "print('\\nClass Percentages (%):')\n",
                "print((df['label'].value_counts(normalize=True) * 100).round(2))\n",
                "\n",
                "dups = df.duplicated(subset=['text']).sum()\n",
                "print(f'\\nDuplicate text messages: {dups} ({dups/len(df)*100:.2f}%)')"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "### Deduplication to Prevent Data Leakage\n",
                "In spam datasets, identical promotional campaigns repeat. If we do not deduplicate, the same message can appear in both training and test sets, artificially inflating test scores. We drop duplicates so the test set reflects **unseen** generalization."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "df_clean = df.drop_duplicates(subset=['text']).reset_index(drop=True)\n",
                "df_clean['target'] = df_clean['label'].map({'ham': 0, 'spam': 1})\n",
                "print(f'Clean records after deduplication: {len(df_clean)}')\n",
                "print(df_clean['label'].value_counts())"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 3: Leakage-Free Train/Test Split\n",
                "We perform the split **before** fitting any vectorizer, using stratified sampling to preserve the 87/13 ham/spam ratio."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "X = df_clean['text']\n",
                "y = df_clean['target']\n",
                "\n",
                "X_train, X_test, y_train, y_test = train_test_split(\n",
                "    X, y, test_size=0.20, random_state=42, stratify=y\n",
                ")\n",
                "print(f'Train set: {len(X_train)} (Spam: {y_train.sum()})')\n",
                "print(f'Test set : {len(X_test)} (Spam: {y_test.sum()})')"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 4 & 5: Baseline and Model Comparison via Pipelines\n",
                "We use `Pipeline` to prevent vectorizer leakage and evaluate candidate models using 5-fold cross-validation on the training set."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "models = {\n",
                "    'Dummy (Most Frequent)': Pipeline([\n",
                "        ('vec', CountVectorizer()),\n",
                "        ('clf', DummyClassifier(strategy='most_frequent'))\n",
                "    ]),\n",
                "    'CountVec + MultinomialNB': Pipeline([\n",
                "        ('vec', CountVectorizer(lowercase=True)),\n",
                "        ('clf', MultinomialNB())\n",
                "    ]),\n",
                "    'TF-IDF + MultinomialNB': Pipeline([\n",
                "        ('vec', TfidfVectorizer(lowercase=True)),\n",
                "        ('clf', MultinomialNB())\n",
                "    ]),\n",
                "    'CountVec + LogisticRegression': Pipeline([\n",
                "        ('vec', CountVectorizer(lowercase=True)),\n",
                "        ('clf', LogisticRegression(max_iter=1000, random_state=42))\n",
                "    ]),\n",
                "    'TF-IDF + LogisticRegression': Pipeline([\n",
                "        ('vec', TfidfVectorizer(lowercase=True)),\n",
                "        ('clf', LogisticRegression(max_iter=1000, random_state=42))\n",
                "    ])\n",
                "}\n",
                "\n",
                "skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)\n",
                "cv_rows = []\n",
                "for name, pipe in models.items():\n",
                "    res = cross_validate(pipe, X_train, y_train, cv=skf, scoring=['precision', 'recall', 'f1', 'accuracy'])\n",
                "    cv_rows.append({\n",
                "        'Model': name,\n",
                "        'Accuracy': res['test_accuracy'].mean(),\n",
                "        'Precision (Spam)': res['test_precision'].mean(),\n",
                "        'Recall (Spam)': res['test_recall'].mean(),\n",
                "        'F1 (Spam)': res['test_f1'].mean()\n",
                "    })\n",
                "\n",
                "pd.DataFrame(cv_rows).round(4)"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 6: Test Set Evaluation & The Cost of False Positives\n",
                "We fit all models on `X_train` and test on `X_test`. Notice the top-right entry of each confusion matrix: **False Positives (Ham incorrectly blocked)**."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "test_rows = []\n",
                "fitted_pipes = {}\n",
                "for name, pipe in models.items():\n",
                "    pipe.fit(X_train, y_train)\n",
                "    fitted_pipes[name] = pipe\n",
                "    preds = pipe.predict(X_test)\n",
                "    tn, fp, fn, tp = confusion_matrix(y_test, preds, labels=[0, 1]).ravel()\n",
                "    prec = precision_score(y_test, preds, pos_label=1, zero_division=0)\n",
                "    rec = recall_score(y_test, preds, pos_label=1, zero_division=0)\n",
                "    f1 = f1_score(y_test, preds, pos_label=1, zero_division=0)\n",
                "    test_rows.append({\n",
                "        'Model': name,\n",
                "        'Precision': round(prec, 4),\n",
                "        'Recall': round(rec, 4),\n",
                "        'F1-Score': round(f1, 4),\n",
                "        'FP (Ham Blocked)': fp,\n",
                "        'FN (Spam Missed)': fn\n",
                "    })\n",
                "\n",
                "pd.DataFrame(test_rows)"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "### Visualizing Confusion Matrix for TF-IDF + MultinomialNB"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "best_model = fitted_pipes['TF-IDF + MultinomialNB']\n",
                "cm = confusion_matrix(y_test, best_model.predict(X_test), labels=[0, 1])\n",
                "disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=['Ham (Inbox)', 'Spam (Junk)'])\n",
                "disp.plot(cmap='Blues', values_format='d')\n",
                "plt.title('Confusion Matrix: TF-IDF + MultinomialNB\\n(Notice FP = 0)')\n",
                "plt.show()"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 7: Safe Error Analysis (PII Redacted)\n",
                "We safely inspect misclassifications with all phone numbers, URLs, and emails redacted."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "def redact(text):\n",
                "    text = re.sub(r'\\b\\d{5,11}\\b', '[NUM_REDACTED]', text)\n",
                "    text = re.sub(r'https?://[^\\s]+', '[URL_REDACTED]', text)\n",
                "    return text\n",
                "\n",
                "y_preds = best_model.predict(X_test)\n",
                "y_probas = best_model.predict_proba(X_test)[:, 1]\n",
                "\n",
                "print('=== False Negatives (Missed Spam) ===')\n",
                "count = 0\n",
                "for text, yt, yp, p in zip(X_test, y_test, y_preds, y_probas):\n",
                "    if yt == 1 and yp == 0:\n",
                "        print(f'\\nCase #{count+1} | P(Spam)={p:.4f}')\n",
                "        print(f'Text: {redact(text)}')\n",
                "        count += 1\n",
                "        if count >= 3:\n",
                "            break"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 8: Preprocessing & Feature Engineering Ablations\n",
                "We test whether stopword removal, bigrams, or sublinear scaling improve CV performance on the training set."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "variants = {\n",
                "    'Default (Unigram, No Stopwords)': Pipeline([('v', TfidfVectorizer()), ('c', MultinomialNB())]),\n",
                "    '+ Stopword Removal': Pipeline([('v', TfidfVectorizer(stop_words='english')), ('c', MultinomialNB())]),\n",
                "    '+ Bigrams (1, 2)': Pipeline([('v', TfidfVectorizer(ngram_range=(1, 2))), ('c', MultinomialNB())]),\n",
                "    '+ Sublinear TF': Pipeline([('v', TfidfVectorizer(sublinear_tf=True)), ('c', MultinomialNB())])\n",
                "}\n",
                "\n",
                "v_rows = []\n",
                "for vname, vpipe in variants.items():\n",
                "    res = cross_validate(vpipe, X_train, y_train, cv=skf, scoring=['precision', 'recall', 'f1'])\n",
                "    v_rows.append({\n",
                "        'Variant': vname,\n",
                "        'Precision': round(res['test_precision'].mean(), 4),\n",
                "        'Recall': round(res['test_recall'].mean(), 4),\n",
                "        'F1-Score': round(res['test_f1'].mean(), 4)\n",
                "    })\n",
                "pd.DataFrame(v_rows)"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 9: Qualitative Robustness Checks\n",
                "We test adversarial variations (leetspeak, obfuscated URLs, promotional words in legitimate contexts)."
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "test_cases = [\n",
                "    ('Congratul@tions! You are a WINN3R. Cl@im your FR33 gift c@rd.', 'Spam (Obfuscated)'),\n",
                "    ('Parcel delivery tracking #84920. Confirm address: bit.ly/delivery', 'Spam (URL Link)'),\n",
                "    ('Congratulations team! We won the innovation award. Free lunch coupon for everyone.', 'Ham (Workplace)'),\n",
                "    ('URGENT: Mom needs you to call her mobile right away.', 'Ham (Urgent Family)')\n",
                "]\n",
                "\n",
                "for text, intent in test_cases:\n",
                "    pred = 'SPAM' if best_model.predict([text])[0] == 1 else 'HAM'\n",
                "    p_spam = best_model.predict_proba([text])[0][1]\n",
                "    print(f'Expected: {intent:20s} | Predicted: {pred:4s} (P(Spam)={p_spam:.4f}) | Text: {text[:50]}...')"
            ]
        },
        {
            "cell_type": "markdown",
            "metadata": {},
            "source": [
                "## Step 10: Interactive Spam Checker Demo\n",
                "Try your own custom message below!"
            ]
        },
        {
            "cell_type": "code",
            "execution_count": None,
            "metadata": {},
            "outputs": [],
            "source": [
                "def check_message(text):\n",
                "    pred = 'SPAM' if best_model.predict([text])[0] == 1 else 'HAM (Legitimate)'\n",
                "    probs = best_model.predict_proba([text])[0]\n",
                "    print(f'Prediction      : {pred}')\n",
                "    print(f'Spam Probability: {probs[1]:.4f} | Ham Probability: {probs[0]:.4f}')\n",
                "    print('[!] CAUTION: Statistical confidence is not a guarantee. Predictions can produce False Positives.')\n",
                "\n",
                "check_message('Hey, are you free for coffee this afternoon?')"
            ]
        }
    ],
    "metadata": {
        "language_info": {"name": "python", "version": "3.11.0"},
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}
    },
    "nbformat": 4,
    "nbformat_minor": 4
}

out_path = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "notebooks",
    "spam_classification_guide.ipynb"
)

with open(out_path, "w", encoding="utf-8") as f:
    json.dump(nb, f, indent=2)

print(f"Jupyter notebook created successfully at: {out_path}")
