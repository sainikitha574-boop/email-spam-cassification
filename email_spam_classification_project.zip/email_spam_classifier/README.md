# Email & SMS Spam Classification with NLP

[![Python 3.11](https://img.shields.io/badge/Python-3.11-3776AB.svg?style=flat&logo=python&logoColor=white)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-1.3+-F7931E.svg?style=flat&logo=scikit-learn&logoColor=white)](https://scikit-learn.org/)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC_BY_4.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

> **Guiding Question:** *Can a text classifier distinguish spam from legitimate email while making false positives easy to understand?*

This repository provides an educational, beginner-friendly Natural Language Processing (NLP) project comparing **Multinomial Naive Bayes** and **Logistic Regression** for spam classification. It emphasizes **data leakage prevention**, **the asymmetric cost of False Positives**, **safe PII redaction**, **robustness edge-case checks**, and an **interactive demonstration**.

---

## Project Structure

```
email_spam_classifier/
│
├── data/
│   ├── SMSSpamCollection            # UCI Corpus (5,574 labeled messages)
│   └── readme                       # Original UCI documentation & license
│
├── src/
│   ├── __init__.py
│   ├── dataset.py                   # Data loading, EDA, and regex PII redaction
│   ├── pipeline.py                  # Scikit-learn Pipelines (zero data leakage)
│   ├── evaluate.py                  # Evaluation metrics, Stratified CV, threshold analysis
│   ├── error_analysis.py            # Diagnostic review of FPs and FNs with redacted text
│   ├── robustness.py                # Edge-case checks (leetspeak, obfuscated URLs, promo ham)
│   └── demo.py                      # Interactive terminal demo & prediction engine
│
├── notebooks/
│   └── spam_classification_guide.ipynb   # Step-by-step Jupyter Notebook with explanations
│
├── models/
│   └── best_spam_pipeline.joblib    # Trained, serialized TF-IDF + MultinomialNB pipeline
│
├── reports/
│   ├── final_project_report.md      # Comprehensive research report & 10-slide outline
│   ├── model_comparison.csv         # Test-set metrics across all evaluated pipelines
│   ├── preprocessing_comparison.csv # Feature ablation results (Stopwords, Bigrams, etc.)
│   ├── threshold_analysis.csv       # Precision-Recall trade-off table
│   ├── robustness_results.csv       # Qualitative robustness test log
│   ├── error_analysis_redacted.txt  # Redacted misclassified examples
│   └── confusion_matrix.png         # Confusion matrix visualization
│
├── app.py                           # Zero-dependency local HTTP server for web demo
├── web_demo.html                    # Sleek, interactive web demo (with client-side fallback)
├── run_experiments.py               # End-to-end experiment runner script
├── generate_notebook.py             # Script generating the Jupyter notebook
├── run_all.bat                      # Windows one-click batch runner
├── requirements.txt                 # Project dependencies
└── README.md                        # Project documentation (this file)
```

---

## Quick Start Guide

### 1. Prerequisites & Environment Setup
Clone or unzip this project into your preferred directory:
```bash
# Verify Python 3.9+ is installed
python --version

# Install dependencies
pip install -r requirements.txt
```

### 2. Run All Experiments End-to-End
Execute the complete experimental pipeline:
```bash
python run_experiments.py
```
This script will:
1. Load and explore the dataset (`data/SMSSpamCollection`).
2. Deduplicate messages to prevent test set data leakage.
3. Perform a stratified 80/20 train/test split.
4. Run 5-fold cross-validation on candidate pipelines.
5. Evaluate all models on the untouched test set.
6. Generate confusion matrix plots and the error analysis report.
7. Conduct preprocessing ablation experiments and robustness checks.
8. Save the best pipeline to `models/best_spam_pipeline.joblib`.

### 3. Launch the Interactive Demo
You have two ways to run the demo:

#### Option A: Interactive Web UI (Recommended)
Run the built-in zero-dependency server:
```bash
python app.py
```
Then open your web browser to: **`http://localhost:8080`**

*(Note: You can also simply double-click `web_demo.html` in Windows Explorer to use the client-side demonstration mode directly!)*

#### Option B: Terminal Demo
```bash
python src/demo.py
```

### 4. Open the Jupyter Notebook
```bash
jupyter notebook notebooks/spam_classification_guide.ipynb
```

---

## Dataset Citation & Ethics

- **Dataset:** SMS Spam Collection
- **Authors:** Tiago A. Almeida, José María Gómez Hidalgo, and Akebo Yamakami (2012)
- **Repository:** UCI Machine Learning Repository
- **DOI:** [10.24432/C5CC84](https://archive.ics.uci.edu/dataset/228/sms+spam+collection)
- **Labels:** `ham` (legitimate) and `spam` (unsolicited commercial/phishing)
- **Privacy & Safety:** All text messages inspected during error analysis or robustness checks are automatically sanitized using regex to redact phone numbers, numeric shortcodes, email addresses, and URLs.

---

## Summary of Results

### Test Set Performance (1,035 Untouched Samples)
*Positive class: SPAM (1). Metric averaging: Binary.*

| Pipeline Model | Precision (Spam) | Recall (Spam) | F1-Score | FP (Ham Blocked) | FN (Spam Missed) |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Dummy (Most Frequent Baseline)** | 0.0000 | 0.0000 | 0.0000 | 0 | 128 |
| **CountVec + MultinomialNB** | 0.9587 | **0.9062** | **0.9317** | 5 | 12 |
| **TF-IDF + MultinomialNB (Best for FP Control)** | **1.0000** | 0.6016 | 0.7512 | **0** | 51 |
| **CountVec + LogisticRegression** | 0.9569 | 0.8672 | 0.9098 | 5 | 17 |
| **TF-IDF + LogisticRegression** | 0.9579 | 0.7109 | 0.8161 | 4 | 37 |

### Why False Positives Matter Most
In email and messaging systems:
- A **False Positive** (a legitimate email routed to Spam) can cause a user to miss a job offer, court date, medical test result, or two-factor code.
- A **False Negative** (a spam email routed to Inbox) is easily deleted.
- **`TF-IDF + MultinomialNB` achieved 0 False Positives on the test set**, making it the safest model against costly inbox blocking.

---

## Safe-Use Limitations

1. **Educational Purpose Only:** This project is an instructional demonstration of statistical text classification. It is not intended or certified for production email server security.
2. **Lack of Protocol & Network Signals:** Real-world enterprise spam engines (e.g., Google Workspace, Microsoft 365) rely heavily on network reputation, sender IP address blacklists, SPF/DKIM authentication, and domain age.
3. **Attachment & Malware Blindness:** This model analyzes plain text tokens only; it does not scan attachments, executable files, or macro-enabled documents.
4. **Adversarial Evasion:** Simple token transformations (leetspeak like `FR33`, image-based spam, or homoglyph character substitutions) easily evade pure bag-of-words classifiers.
